#!/usr/local/bin/perl -w
#use strict;
# 02/10/07
# read in multiple motif files, combine them and then write into a single file.
# == cat motif.1 motif.2 ... motif.10 > motif.all
# insert an empty line between inout files, but no line added at the end of the last file.

$argc = @ARGV;
$argc == 3 || die "Provide all widths file name, input motif file name and output combined motif file name.\n";

$widthname = $ARGV[0];
$membername = $ARGV[1];
$outcombinename = ">".$ARGV[2];
open(WIDTHFILE, $widthname);
open(OUTCOMBINEFILE, $outcombinename);

$datline = <WIDTHFILE>;
chop($datline);
@widths = split(" ",$datline);
close(WIDTHFILE);
$total = scalar(@widths);

# read in result cluster members.
$count =0;
for($j= 0;$j<$total;$j++)
{
	$inmembername = $membername.".".$widths[$j];
##	print "$inmembername\n";
	open(INMEMBERFILE, $inmembername);     
	while($datline = <INMEMBERFILE>)
	{
#		print "$datline";
		print OUTCOMBINEFILE "$datline";
		$count ++;
	}
	close(INMEMBERFILE);
	$order = $j+1;
	print "file $order read in, width = $widths[$j], lines = $count\n";  
	if($j<($total-1))	
	{
	        print OUTCOMBINEFILE "\n";	
	}
}
close(OUTCOMBINEFILE);
print "total lines = $count\n"; 

