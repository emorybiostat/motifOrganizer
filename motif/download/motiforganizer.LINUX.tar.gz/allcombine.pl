#!/usr/local/bin/perl -w
# use strict;
# 01/28/07
# read in multiple cluster memberships
# output membership information in the final combined cluster.
# output shift position information in the final combined cluster.

$argc = @ARGV;
$argc == 9 || die "Provide input match file, cluster membership file name, 
all widths file name, combined member file, combined shift position file, 
combined width file, output all member file name, output all shift position file name and output all width file name.\n";

$matchname = $ARGV[0];
$membername = $ARGV[1];
$widthname = $ARGV[2];
$incombinename = $ARGV[3];
$incombineshiftname = $ARGV[4];
$incombinewidthname = $ARGV[5];
$outallmembername = ">".$ARGV[6];
$outallshiftname = ">".$ARGV[7];
$outallwidthname = ">".$ARGV[8];

# read in allwithds file.
open(WIDTHFILE, $widthname);
$datline = <WIDTHFILE>;
chop($datline);
@widths = split(" ",$datline);
close(WIDTHFILE);
$total = scalar(@widths);

open(MATCHFILE, $matchname);
open(OUTALLMEMBERFILE, $outallmembername);
open(OUTALLSHIFTFILE, $outallshiftname);
open(OUTALLWIDTHFILE, $outallwidthname);

#read in match file.
my @match;
$count =0;
while($datline = <MATCHFILE>)
{
#               print "$datline\n";
#               exit(0);
                chop($datline);
                @line = split(" ",$datline);
                $subsetsize = scalar(@line);
#                $clustsize[$linecount] = $clsize;
#               print "cluster size = $clustsize[$linecount]\n";
#               exit(0);
                for($k=0;$k<$subsetsize;$k++)
                {
			$match[$count][$k] = $line[$k];		
###			print "$line[$k]  ";
		}
##		print "\n\n\n\n\n";
		$count ++;
}
close(MATCHFILE);
print "count = $count\n";
#exit(0);


# read in result cluster members.
my @clustsize;
my @member;
my @shift;
$count =0;
$linecount =0;
$filecount=0;
for($j= 0;$j<$total;$j++)
{
#	$begin = $count;
	$inmembername = $membername.".".$widths[$j];
	$order = $j +1;
	print "$order, $inmembername\n";
	open(INMEMBERFILE, $inmembername);
	while($datline = <INMEMBERFILE>)
	{
#		print "$datline\n";
#		exit(0);
	        chop($datline);
        	@line = split(" ",$datline);
		$clsize = scalar(@line);
		$clustsize[$linecount] = $clsize;
##		print "cluster size = $clustsize[$linecount]\n";
#		exit(0);
		for($k=0;$k<$clsize;$k++)
		{
			$member[$linecount][$k]= $match[$filecount][$line[$k]];	
#####			$member[$linecount][$k]= $begin + $line[$k];
##			print "$member[$linecount][$k] ";
		}
##		print "\n";
		$linecount ++;
		$count = $count + $clsize;		
	}
	close(INMEMBERFILE);
	$filecount++;
}
print "total files = $filecount\n";
print "total lines = $linecount\n";
print "total motifs = $count\n"; 
#exit(0);
#for($j=0;$j<$linecount;$j++)
#{
#	print "j=$j clust size = $clustsize[$j]\n";
#}
#
open(INCOMBINEFILE, $incombinename);
open(INCOMBINESHIFTFILE, $incombineshiftname); 
open(INCOMBINEWIDTHFILE, $incombinewidthname);

$count =0;
while($datline = <INCOMBINEFILE>)
{
        	chop($datline);
                @line = split(" ",$datline);
                $clsize = scalar(@line);
# shift:
		$shiftdatline = <INCOMBINESHIFTFILE>;
                chop($shiftdatline);
                @shiftline = split(" ",$shiftdatline);
# width:
                $widthdatline = <INCOMBINEWIDTHFILE>;
                chop($widthdatline);
                @widthline = split(" ",$widthdatline);
		$widthpos = $widthline[0];
                for($k=0;$k<$clsize;$k++)
                {
           		$lineorder = $line[$k];
			$shiftpos = $shiftline[$k];
#                        $widthpos = $widthline[$k];
##			print "$lineorder\n";
##			print  "cluster size = $clustsize[$lineorder]\n";
#			exit(0);
			for($m=0;$m<$clustsize[$lineorder];$m++)
			{
##                        	print "$member[$lineorder][$m] ";
##				print "$shiftpos "; 
##				print "$widthpos\n";
                        	print OUTALLMEMBERFILE "$member[$lineorder][$m] ";
				print OUTALLSHIFTFILE "$shiftpos ";
#                               print OUTALLWIDTHFILE "$widthpos ";
#				exit(0);			
                	}
		}
##              print "\n";
                print OUTALLMEMBERFILE "\n";
		print OUTALLSHIFTFILE "\n";  
                print OUTALLWIDTHFILE "$widthpos\n";
                $count ++;
}
close(INCOMBINEFILE);
close(INCOMBINESHIFTFILE);
close(INCOMBINEWIDTHFILE);
close(OUTALLMEMBERFILE);
close(OUTALLSHIFTFILE);
close(OUTALLWIDTHFILE);
print "total number of clusters is $count.\n";


 
