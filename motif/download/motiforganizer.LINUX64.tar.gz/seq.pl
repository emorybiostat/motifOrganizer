#!/usr/local/bin/perl -w
#use strict;
# 01/28/07
# read in motif sequences
# output motifs in clusters

$argc = @ARGV;
$argc == 5 || die "Provide input sequence file, result file names and output fasta format sequence, name and pure sequences.\n";

$inputseqname = $ARGV[0];
open(INPUTSEQFILE, $inputseqname);
$inputresultname = $ARGV[1];
open(INPUTRESULTFILE, $inputresultname);
$outfastaname = ">".$ARGV[2];
open(OUTFASTAFILE, $outfastaname);
$outputnamename = ">".$ARGV[3];
open(OUTPUTNAMEFILE, $outputnamename);
$outseqname = ">".$ARGV[4];
open(OUTSEQFILE, $outseqname);

# read in from input motif sequence file.
my @name;
my @longname;
my @seq;
my @depth;
my @width;

$count =0;
$rowcount =0;
while($datline = <INPUTSEQFILE>)
{
	$first = substr($datline,0,1);
	chop($datline);
	$len = length($datline); 
	if($len ==0)
	{
		$depth[$count] = $rowcount;
		$count ++;
		$rowcount =0;
	}
	elsif($first eq ">")
	{
#		print "rowcount = $rowcount\n";
#		exit(0);
		$newline = substr($datline, 1);
		if($rowcount==0)
		{
 	        	@line = split(" ",$newline);
			$name[$count]= $line[0];
##			print "name = $line[0]\n";
		}
                $longname[$count][$rowcount] = $newline;
	}
	else
	{
		$seq[$count][$rowcount] = $datline;
		if($rowcount==0)
                {
                        $width[$count] = $len;  
                }
		$rowcount ++;	
	}
}
$depth[$count] = $rowcount;
$total = $count + 1;
close(INPUTSEQFILE);
print "total = $total\n";

#for($j=0;$j<$total;$j++)
#{
###	print "$j, name=$name[$j]\n";
###      print "$width[$j]  $depth[$j]\n";
#	for($k=0;$k<$depth[$j];$k++)
#	{
###	        print "$longname[$j][$k]\n";
##		print "$seq[$j][$k]\n";
#	}
##	print "\n";
#}
#exit(0);

# read in result cluster members.
my @clustsize;
my @member;
$count =0;
while($datline = <INPUTRESULTFILE>)
{
        chop($datline);
        @line = split(" ",$datline);
	$clsize = scalar(@line);
	$clustsize[$count] = $clsize;
	for($j=0;$j<$clsize;$j++)
	{
		$member[$count][$j]=$line[$j];
	}
	$count ++;		
}
close(INPUTRESULTFILE);
$number = $count;
print "number = $number\n";

# produce FASTA format file
for($j=0;$j<$number;$j++)
{
	$clusterid = $j+1;
	for($k=0;$k<$clustsize[$j];$k++)
        {
		$order = $k+1;
		print "$member[$j][$k] ";
		for($m=0; $m<$depth[$member[$j][$k]];$m++)
		{
			$roworder = $m+1;
			$motiforder = $member[$j][$k]+1;
	                print OUTFASTAFILE "> $inputseqname-cluster$clusterid motif$order-row$roworder motifID=$motiforder $longname[$member[$j][$k]][$m]\n";
			print OUTFASTAFILE "$seq[$member[$j][$k]][$m]\n";
			print OUTSEQFILE "$seq[$member[$j][$k]][$m]\n";
			print OUTPUTNAMEFILE "$longname[$member[$j][$k]][$m]\n";
##			print "> $inputseqname-cluster$clusterid motif$order-row$roworder motifID=$motiforder $longname[$member[$j][$k]][$m]\n";
#                        print "$seq[$member[$j][$k]][$m]\n";
		}
        }
	print "\n";
	if($j<($number-1))
	{
#		print "\n";
		print OUTFASTAFILE "\n";
		print OUTSEQFILE "\n";
		print OUTPUTNAMEFILE "\n";
	}
#	print OUTFASTAFILE "\n";
}


