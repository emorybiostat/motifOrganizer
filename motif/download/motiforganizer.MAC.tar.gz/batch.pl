#!/usr/local/bin/perl
# use strict;
# 04/14/07
# script for running motiforganier automatically. 
# 

$argc = @ARGV;
$argc == 6 || die "6 parameters are needed. Provide provide;
		1. input filename, 
		2. number of chains, 
		3. number of iteration cycles, 
		4. number of initial cluster sizes, 
		5. number of initial clusters (used in combine step) and 
		6. maximum amount of shifts.\n";

$inputfilename = $ARGV[0];
$numchains = $ARGV[1];
$numcycles = $ARGV[2];
$initialsizes= $ARGV[3];
$initialclusters = $ARGV[4];
$maxshifts = $ARGV[5];

open(LOGFILE,">bmc.log");
#open(OUTFILE,">bmc.out"); 
#open(TRUTHFILE, $truthname);
#$matchname = $ARGV[1];
#open(MATCHFILE, $matchname);
#$outputname = ">".$ARGV[2];
#open(OUTPUTFILE, $outputname);

###
### step 1.  split the input data, generate "allwidths" file and "match.txt" file.
###
$title = "Step 1. Split.";
$command = "perl split.pl ".$inputfilename." input";
&runcommand($title,$command);
#exit(0);

###
### step 2. find out what are all widths.
###
print LOGFILE "Step 2. Get widths.\n";
print "Step 2. Get widths.\n";
open(WIDTHFILE, "allwidths") or die " There is an error, can not open file allwidths.\n";
my @widths;
while($datline = <WIDTHFILE>)
{
        chop($datline);
        @data = split(" ",$datline);
	$total = scalar(@data);
	for($j=0;$j<$total;$j++)
	{
		$widths[$j]= $data[$j];
	}	
}
close(WIDTHFILE);
print LOGFILE "Job completed on ";
print "Job completed on ";
&printtime;
print LOGFILE ".\n";
print ".\n";
#exit(0);

###
### step 3.  run bmcfix on individual subsets.
###
print LOGFILE "Step 3. Run BMCFIX.\n";
print "Step 3. Run BMCFIX.\n";
for($j=0;$j<$total;$j++)
{
#	print "./bmcfix input.".$widths[$j]." out.".$widths[$j]." member.".$widths[$j]." ".$numchains." ".$numcycles." ".$initialsizes."\n";
#	exit(0);
	system("./bmcfix input.".$widths[$j]." out.".$widths[$j]." member.".$widths[$j]." ".$numchains." ".$numcycles." ".$initialsizes." >> bmc.out") == 0 or die 
	" Unable to perform ./bmcfix input.".$widths[$j]." out.".$widths[$j]." member.".$widths[$j]." ".$numchains." ".$numcycles." ".$initialsizes."\n";;
#	print "perl seq.pl input.".$widths[$j]." member.".$widths[$j]." fasta.".$widths[$j]." names.".$widths[$j]." seq.".$widths[$j]."\n";
#	exit(0);
	system("perl seq.pl input.".$widths[$j]." member.".$widths[$j]." fasta.".$widths[$j]." names.".$widths[$j]." seq.".$widths[$j]." >> bmc.out") ==0 or die
	"Unable to perform perl seq.pl input.".$widths[$j]." member.".$widths[$j]." fasta.".$widths[$j]." names.".$widths[$j]." seq.".$widths[$j]."\n";
#	exit(0);
}
print LOGFILE "Job completed on ";
print "Job completed on ";
&printtime;
print LOGFILE ".\n";
print ".\n";
#exit(0);

###
### step 4. collect information from all subsets.
###
$title = "Step 4. Collect information.";
$command = "perl motifstack.pl allwidths fasta allmotifs";
&runcommand($title,$command);
#exit(0);

###
### step 5. run bmcvar on combined data.
###
$title = "Step 5. Run BMCVAR.";
$command = "./bmcvar allmotifs out.all member.all shift.all width.all ".$numchains." ".$numcycles." ".$initialclusters." ".$maxshifts;
&runcommand($title,$command);
#exit(0);

###
### step 6. collect all information. 
### 
$title = "Step 6. Collect results.";
$command = "perl allcombine.pl match.txt member allwidths member.all shift.all width.all member.combined shift.combined width.combined";
&runcommand($title,$command);

###
### step 7. clean up results by removing insignificant clusters and poor-fit motifs. 
###
$title = "Step 7. Run resultview and cleanup program.";
$command = "./varview ".$inputfilename." member.combined shift.combined width.combined out.final out.final.clean member.final.clean 0.5 0";
&runcommand($title,$command);
#exit(0);

###
### step 8. remove intermediate results files. 
###
print LOGFILE "Step 8. Remove intermediate files.\n";
print "Step 8. Remove intermediate files.\n";
for($j=0;$j<$total;$j++)
{
	system("rm -fr input.".$widths[$j]) ==0 or die " Unable to remove file input.".$widths[$j]."\n";
	system("rm -fr out.".$widths[$j]) ==0 or die " Unable to remove file out.".$widths[$j]."\n";
	system("rm -fr member.".$widths[$j]) ==0 or die " Unable to remove file member.".$widths[$j]."\n";
	system("rm -fr fasta.".$widths[$j]) ==0 or die " Unable to remove file fatsa.".$widths[$j]."\n";
	system("rm -fr names.".$widths[$j]) ==0 or die " Unable to remove file names.".$widths[$j]."\n";
	system("rm -fr seq.".$widths[$j]) ==0 or die " Unable to remove file seq.".$widths[$j]."\n";
}
system("rm -fr allwidths") ==0 or die " Unable to remove file allwidths.\n";
system("rm -fr allmotifs") ==0 or die " Unable to remove file allmotifs.\n";
system("rm -fr match.txt") ==0 or die " Unable to remove file match.txt.\n";
system("rm -fr out.all") ==0 or die " Unable to remove file out.txt.\n";
system("rm -fr member.all") ==0 or die " Unable to remove file member.all.\n";
system("rm -fr shift.all") ==0 or die " Unable to remove file shift.all.\n";
system("rm -fr width.all") ==0 or die " Unable to remove file width.all.\n";
system("mv member.combined member.final") ==0 or die " Unable to mv member.combined member.final.\n";
system("rm -fr shift.combined") ==0 or die " Unable to remove file shift.combined.\n";
system("rm -fr width.combined") ==0 or die " Unable to remove file width.combined.\n";
print LOGFILE "Job completed on ";
print "Job completed on ";
&printtime;
print LOGFILE ".\n\n";
print ".\n\n";

print LOGFILE "There are $total subsets. the widths are:";
print "There are $total subsets. the widths are:";
for($j=0;$j<$total;$j++)
{
	print LOGFILE "$widths[$j], ";
	print "$widths[$j], ";
}
print LOGFILE ".\nplease see out.final, member.final, out.final.clean and member.final.clean for result cluster information.\n";
print ".\nplease see out.final, member.final, out.final.clean and member.final.clean for result cluster information.\n";
close(LOGFILE); 

sub printtime
{
@months = qw(Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec);
@weekDays = qw(Sun Mon Tue Wed Thu Fri Sat Sun);
($second, $minute, $hour, $dayOfMonth, $month, $yearOffset, $dayOfWeek, $dayOfYear, $daylightSavings) = localtime();
$year = 1900 + $yearOffset;
$theTime = "$hour:$minute:$second, $weekDays[$dayOfWeek] $months[$month] $dayOfMonth, $year";
print LOGFILE $theTime;
print $theTime;
}

sub runcommand 
{
	my ($title, $command) = @_;
	print LOGFILE "$title\n";
	print "$title\n";
	system($command." >> bmc.out") == 0 or die "Unable to perform $command";
	print LOGFILE "Job completed on "; 
	print "Job completed on "; 
	&printtime;
	print LOGFILE ".\n";
	print ".\n"; 
}
