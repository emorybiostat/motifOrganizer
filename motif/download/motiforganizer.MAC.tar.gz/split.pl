#!/usr/local/bin/perl
#use strict;
# 03/24/07
# split the original motif file into parts by their width.

$argc = @ARGV;
$argc == 2 || die "Provide input and output file name.\n";

$inputname = $ARGV[0];
$outputname = ">".$ARGV[1];
open(INPUTFILE, $inputname);
open(WIDTHFILE, ">allwidths");
open(MATCHFILE, ">match.txt");
# read in result information
my @counter;
my @match;
for($j=6;$j<=30;$j++)
{
	$counter[$j]=0;
}
$count =0;

my @seq;
$count=0;
$total=0;
while($datline = <INPUTFILE>)
{
	chop($datline);
#	print "$datline\n";
#	exit(0);
	if(substr($datline,0,1) eq ">")
	{
		$datline1 = <INPUTFILE>;
	        chop($datline1);
		$width = length($datline1);
		$seq[$total][$count][0] = $datline;
#		print "$seq[$total][$count][0]\n";
		$seq[$total][$count][1] = $datline1;		
		$count ++;
	}
	else
	{
		$allwidths[$total] = $width;
		$alldepths[$total] = $count;
		$count=0;
#		print "width=$width\n";
		$total++;
	}
}
$allwidths[$total] = $width;
$alldepths[$total] = $count;
#print "count=$count,\n";
#print "width=$width.\n";
$total++;

close(INPUTFILE);
print "total motif count = $total\n";
#exit(0);

@a = sort {$a <=>$b} @allwidths;
my @sortwidth;
$sortwidth[0] = $a[0];
$count=1;
for($j=1;$j<$total;$j++)
{
	#print "$a[$j].\n";
	if($a[$j]>$a[$j-1])
	{
		$sortwidth[$count] = $a[$j];
		$count++;
	}
}
print "number of different motif widths = $count.\n";
for($j=0;$j<$count;$j++)
{
        print "$sortwidth[$j]  ";
	print WIDTHFILE "$sortwidth[$j]  ";	
}
print "\n";
print WIDTHFILE "\n";
#exit(0);

$sum=0;
for($j=0;$j<$count;$j++)
{
	$motifcount =0;
	open(OUTPUTFILE,$outputname.".".$sortwidth[$j]);
	for($k=0;$k<$total;$k++)
	{
		if($allwidths[$k]==$sortwidth[$j])
		{
			print MATCHFILE "$k\t";
#			print "$allwidths[$k], $sortwidth[$j].\n";
			if($motifcount>0)
			{
				print OUTPUTFILE "\n";
			} 
			$motifcount++;
			for($m=0;$m<$alldepths[$k];$m++)
			{
				print OUTPUTFILE "$seq[$k][$m][0]\n";
#				print "$seq[$k][$m][0]\n";
				print OUTPUTFILE "$seq[$k][$m][1]\n";
			}
		}
	}
	close(OUTPUTFILE);
	print MATCHFILE "\n";
	print "width = $sortwidth[$j], motifcount = $motifcount\n";	
	$sum = $sum + $motifcount;
}
close(MATCHFILE);
	print "total motif count = $sum.\n";
exit(0);

